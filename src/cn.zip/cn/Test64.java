package cn;

import java.util.ArrayList;
import java.util.List;

public class Test64 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(21);

	}

}
