package cn;
//http://docs.oracle.com/javase/tutorial/java/javaOO/methods.html
public class Base {

	public static void main(String[] args) {
		System.out.println("Base " + args[2]);
		 
	}

}
