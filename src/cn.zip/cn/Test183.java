package cn;

public class Test183 {

	public static void main(String[] args) {
		float flt1 = 100F;
		System.out.println(flt1);
		float flt2 = (float)1_11.00;
		System.out.println(flt2);
		float flt3 = 100;
		System.out.println(flt3);
		double y1 = 203.22;
//		float flt4 = y1;
		System.out.println(y1);
		int y2 = 100;
		float flt5 = (float)y2;
		System.out.println(y2);

	}

}
