package cn;

public class Test154 {

	public static void main(String[] args) {
		float myarray[] = {10.20f, 20.30f, 30.40f,50.60f};
		int index = 0;
		boolean isFound = false;
		float key = 30.40f;
		
		while(key ==myarray[index++]){
			isFound = true;
		}
		
//		while (index <= 4){
//			if (key == myarray[index]){
//				index++;
//				isFound = true;
//				break;
//			}
//		}
		
//		while (index++ < 5){
//			if (key == myarray[index]){
//				index++;
//				isFound = true;
//			}
//		}
		
//		while (index < 5){
//			if (key == myarray[index]){
//				isFound = true;
//				break;
//			}
//			index++;
//		}
		
		System.out.println(isFound);

	}

}
