package cn;

public class Test72 {

	int sum = 0;
	public void doCheck (int number) {
		if(number%2 ==0){
//			break;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
