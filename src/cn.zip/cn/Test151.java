package cn;

public class Test151 {

	public static void main(String[] args) {
		float x = 22.00f % 3.00f;
		int y = 22%3;
		System.out.println(x+","+y);

	}

}
