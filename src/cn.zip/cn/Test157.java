package cn;

public class Test157 {

	public static void main(String[] args) {
		try{
			Double number = Double.valueOf("120D");
			System.out.println(number);
		}catch(NumberFormatException ex){

		}


	}

}
