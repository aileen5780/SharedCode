package cn;

public class Test169 {

	public static void main(String[] args) {
		System.out.println(28+5 <= 4+29);
		System.out.println((28+5) <= (4+29));

	}

}
