package cn;

public class Test156 {

	public static void main(String[] args) {
		String s = "A";
		
		switch(s){
		case "a":
			System.out.println("Simaple A");
		default:
			System.out.println("Default");
		case "A":
			System.out.println("Capital A");
		}

	}

}
