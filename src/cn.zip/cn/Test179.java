package cn;

public class Test179 {

	public static void main(String[] args) {
		Integer num = Integer.parseInt(args[1]);
		System.out.println("Number is "+ num);

	}

}
