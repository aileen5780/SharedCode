package cn;

public class Test74 {
	int x;
	Test74(){
		this(10);
	}

	Test74(int x){
		this.x = x;
	}

}

class Car extends Test74{
	int y;
	Car(){
		super();
//		this(20);
	}
}
