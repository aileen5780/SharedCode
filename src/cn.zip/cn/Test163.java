package cn;

public class Test163 {

	public static void main(String[] args) {
		int[] xx = null;
		for (int ii:xx){
			System.out.println(ii);
		}

	}

}
