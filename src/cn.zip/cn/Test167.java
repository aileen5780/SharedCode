package cn;

public class Test167 {

	public static void main(String[] args) {
		int num = 5;
		do{
			System.out.print(num-- + " ");
		}while(num ==0);

	}

}
