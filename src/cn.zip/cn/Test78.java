package cn;

public class Test78 {

	public static void main(String[] args) {
		Test78 t = new Test78();
		int[] arr = new int[10];
		arr = t.subArray(arr, 0, 2);

	}
	public int[] subArray(int[] src, int start, int end){
		return src;
	}
}
