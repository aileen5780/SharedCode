package cn;

public class Test170 {

	public static void main(String[] args) {
		String s = "Java Duke";
		int len = s.trim().length();
		System.out.println(len);

	}

}
