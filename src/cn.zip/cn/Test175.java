package cn;

public class Test175 {
	static double dvalue;
	static Test175 ref1 = new Test175();
	static Test175 ref;
	//toString

	public static void main(String[] args) {
		System.out.println(ref);
		System.out.println(dvalue);
		System.out.println(ref1);
	}

}
