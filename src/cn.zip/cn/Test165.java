package cn;

public class Test165 {

	public static void main(String[] args) {
		int sum = 0;

		for(int x=0; x<=10; x++){
			sum +=x;
//			System.out.println("Sum for 0 to " + x);
//			System.out.println("=" + sum);
			
		}
//		System.out.println("Sum for 0 to " + x);
		System.out.println("=" + sum);

	}

}
