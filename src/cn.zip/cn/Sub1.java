package cn;

public class Sub1 extends Base {

	public static void main(String[] args) {
		System.out.println("Overriden " + args[1]);
		 
	}
	 
}
