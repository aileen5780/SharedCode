package cn;

public class Test181 {
	static String args[] = {"lazy","lion","is","always"};
	public static void main(String[] args) {
		System.out.println(args[1]+" "+args[2]+" "+args[3]+" jumping");

	}

}
