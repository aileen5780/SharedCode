package test200236;

public class Test226 {

	public static int main(String[] args) {
		System.out.println(args[1]);
		return 0;

	}

}
