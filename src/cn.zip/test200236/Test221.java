package test200236;

public class Test221 {

	public static void main(String[] args) {
		int array[] = new int[-2];
	}

}
