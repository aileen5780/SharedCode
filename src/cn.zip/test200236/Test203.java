package test200236;

public class Test203 {
	 
	void main() {	 
	 System.out.println("one");	 
	}
	 
	static void main(String args) {
	 System.out.println("two");	 
	}
	 
	public static void main(String[] args) { 
		System.out.println("three");	 
	}
	 
	void mina(Object[] args) { 
		System.out.println("four"); 
	}
	 
}
 
