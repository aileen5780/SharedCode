package test200236;

public class Test233 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("1Z0");
		String s = sb.toString().concat("-808");
		System.out.println(sb);
		System.out.println(s);

	}

}
