package test200236;

public class Test209 {
	 
	static public void main(String[] args) {
 
		String message = "Hi everyone!";
		System.out.println("message = " + message.replace("e", "X")); 
		System.out.println("message = " + message.replaceAll("o", "T")); 
		
	}
 
}
 