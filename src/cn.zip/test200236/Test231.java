package test200236;

public class Test231 {

	public static void main(String[] args) {
		Object array[];
//		Boolean array1[3];
		int[] array2;
//		Float[2] array3;
		byte x = 1;
		short y = 1;
		long z = 1;
		double s = 1;
		
		
		
		
		

	}

}
