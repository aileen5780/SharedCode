package com;

import java.util.ArrayList;
import java.util.List;

public class Test11 {

//	public static void main(String[] args) {
//		int row = 10;
//		for (; row>0 ;) {
//			int col = row;
//			while (col >=0 ) {
//				System.out.print(col + " ");
//				col -= 2;
//			}
//			row = row/col;
//		}
//
//	}
	
	public static void main(String[] args) {
		List ps = new ArrayList();
		Patient p2 = new Patient("Mike");
		ps.add(p2);
		

		int f = ps.indexOf(p2);
		
		if (f>=0) {
			System.out.println("Mike Found");
		}
		
		Runnable r = new Runnable(){

			@Override
			public void run() {
				System.out.println("Run");
			}
			
		};
		
		Runnable run = () -> {System.out.println("Run");} ;
	}
}
class Patient {
	public Patient(String name){
		
	}
}
