package com;

class CD {
	int r;
	CD(){}
	CD(int r) {
		this.r = r;
	}
}

class DVD extends CD {
	int c;
	

	DVD(int r, int c) {
//		super(r);
		this();
		// TODO Auto-generated constructor stub
	}


	public DVD() {
		// TODO Auto-generated constructor stub
	}
	
}
