package com;

public class Test39 {


		 
		char c;
		 
		boolean b;
		 
		float f;
		 
		void printAll() {
		 
		System.out.println("c = " + c);
		 
		System.out.println("c = " + b);
		 
		System.out.println("c = " + f);
		 
		}
		 
		 
		public static void main(String[] args) {
		 
		Test39 f = new Test39();
		 
		f.printAll();
		 
		}
		 
		}
		 
		 