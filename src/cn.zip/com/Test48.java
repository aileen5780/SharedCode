package com;

public class Test48 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("World");
		
		sb.insert(0, "Hello ");
		System.out.println(sb);

	}

}
