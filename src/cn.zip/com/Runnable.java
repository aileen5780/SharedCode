package com;

interface Runnable {
	public void run();
}
