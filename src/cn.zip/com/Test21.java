package com;

public class Test21 {

	public static void main(String[] args) {
		Test21 t = new Test21();
		try{
			t.doPrint();
			t.doList();
		}catch (Exception e2) {
			System.out.println(e2);
		}
		
		

	}
	
	public void doList() throws Exception{
		throw new Exception("456");
	}
	
	public void doPrint() throws Exception{
		throw new RuntimeException("123");
	}

}
