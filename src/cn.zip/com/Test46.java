package com;

public class Test46 {

	public static void main(String[] args) {
		if (args[0].equals("Hello")?false:true){
			System.out.println("Success");
		}else{
			System.out.println("Failure");
		}

	}

}
