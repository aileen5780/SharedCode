package com;

public class Test18 {

	public static void main(String[] args) {
		int day = 1;
		switch(day){
		case 7: System.out.println("Uranus");
		break;
		
		}

	}

}
