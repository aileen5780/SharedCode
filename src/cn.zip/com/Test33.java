package com;

public class Test33 {

	public static void main(String[] args) {
		int[] intArr = {8, 16, 32, 64, 128};
		
		for (int i : intArr) {
			System.out.print(intArr[i] + "");
			i++;
//			System.out.print(i + " ");
		}

	}

}
