package com;

public class Test60 {
	 
public static void main(String[] args) {
 
int[] arrar = {1,2,3};
 
for ( int i =0;i<1;i++) {
 
}
 
}
 
}

