package test197;

public class MyException extends RuntimeException {

}
