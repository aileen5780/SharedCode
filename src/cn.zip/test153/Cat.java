package test153;

public class Cat extends Animal implements Hunter {

}
