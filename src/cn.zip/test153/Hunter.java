package test153;

public interface Hunter {

}
