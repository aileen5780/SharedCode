package test153;

public class Tiger extends Cat {

}
