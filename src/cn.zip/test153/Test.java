package test153;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList<Animal> myList = new ArrayList<>();
		myList.add(new Cat());
		
//		ArrayList<Cat> myList = new ArrayList<>();
//		myList.add(new Tiger());
		

	}

}
