package test173;

public class Root {
	private static final int MAX = 20000;
	private int method1(){
		int a = 100 + MAX;
		return a;
	}
	protected int method2(){
		int a = 200 + MAX;
		return a;
	}

}
