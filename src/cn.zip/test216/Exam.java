package test216;

public class Exam {
	void method(){}
}
