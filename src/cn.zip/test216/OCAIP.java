package test216;

public class OCAIP extends Exam {
  void method(){}
}
